<nav class="navbar navbar-light navbar-expand-lg fixed-top bg-white clean-navbar">
        <div class="container-fluid" ><a class="logo" href="index.php"><img src="../logo.png" style="height:60px;width:160px;"></a><button class="navbar-toggler" data-toggle="collapse" data-target="#navcol-1"><span class="sr-only">Toggle navigation</span><span class="navbar-toggler-icon"></span></button>
            <div class="collapse navbar-collapse"
                id="navcol-1">
                <ul class="nav navbar-nav ml-auto">
                    
                     <li class="nav-item" role="presentation"><a class="nav-link" href="account.php">My Account</a></li>
                     <li class="nav-item" role="presentation"><a class="nav-link" href="clients.php">Clients</a></li>
                     <li class="nav-item" role="presentation"><a class="nav-link" href="team.php">OCH Team</a></li>
                     <li class="nav-item" role="presentation"><a class="nav-link" href="societies.php">Societies</a></li>
                     <li class="nav-item" role="presentation"><a class="nav-link" href="blogs.php">Blogs</a></li>
                     <li class="nav-item" role="presentation"> <form method="post">
						<input value="Logout" name="logout" style="background-color:white;border:none" type="submit" class="nav-link text-primary"><span><i class="fas fa-sign-out-alt logout-icon"></i></span></form>
					 </li>
                </ul>
            </div>
        </div>
    </nav>