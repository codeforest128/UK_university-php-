<?php




	include('../../classes/DB.php');
	include('../../classes/login.php');
	
    if (!Login::isAdminLoggedIn()) {
         header("Location: login.php");
		}



		if (isset($_COOKIE['SNID']))	{			
			$token = $_COOKIE['SNID'];
			$admin_id = DB::query('SELECT admin_id FROM admin_login_tokens WHERE token=:token', array(':token'=>sha1($token)))[0]['admin_id'];

			
		}
		
		
		if(array_key_exists('logout',$_POST)){
			  DB::query('DELETE FROM admin_login_tokens WHERE admin_id=:admin_id', array(':admin_id'=>Login::isAdminLoggedIn()));
			  header("Location: login.php");
		}

    
		

?>
<?php include('header.php');?>  
         
<section class="account-pages bg-light">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-3">
      <?php include 'left_sidebar.php'; ?>
                
            </div>
			
	
            <div class="col-md-9 account-form">
                <div class="personal-detaile-sec ">
                  <div class="row">
                    <div class="col"><h3>Clients</h3></div>
                    <div class="col text-right"><a href="add_client.php"><button class="btn btn-primary">Add Client</button></a></div>
                  </div>

                  <?php


                  $all_clients = DB::query('SELECT * FROM clients ORDER by id desc');
                  $clients_details = DB::query('SELECT * FROM client_details');



                  ?>
                  

                 <table id="table_id" class="display">
                      <thead>
                        <tr>
                          <th>#</th>
                          <th>Name</th>
                          <th>Email</th>
                          <th>Signer</th>
                          <th>Contacts</th>
                          <th>sign date</th>
                          <th>Signature</th>
                          <th>Action</th>
                        </tr>
                      </thead>
                      <tbody>

                        <?php $countr=0; foreach ($all_clients as $keyCli => $valueCli) { 
                       $id = $valueCli['id'];
                        $conts = DB::query('SELECT * FROM contacts WHERE client_id = :client_id', array(':client_id'=>$id));
                        $noconts = count($conts);
                        $countr++;
                        ?>
                          <tr>
                            <td><?php echo $countr;?></td>
                            <td><?php echo $valueCli['username'];?></td>
                            <td><?php echo $valueCli['email'];?></td>
                            <td><?php echo $valueCli['signer_name'];?></td>
                            <td><?php echo $noconts;  ?></td>
                            <td><?php echo $valueCli['sign_date'];?></td>
                            <td><?php if($valueCli['signature']!=''){ ?><img  src="../client/<?php echo $valueCli['signature'];?>" style="height:50px;"><?php } ?> </td>
                            <td><button class="btn btn-info" onclick="client_details(<?php echo $valueCli['id'];?>)">View Details</button></td>
                          </tr>
                        <?php } ?>
                        
                        
                      </tbody>
                    </table>
        
                      
                    
            </div>
                
            </div>
      
        </div>
    </div>
</section> 





<!-- The Modal -->
<div class="modal" id="client_details">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Client details</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
       <div id="client_details_div"></div>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button"  class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>




<?php include('footer.php'); ?>


<script type="text/javascript">
  
function client_details(ids) {

  $('#client_details_div').html('<center><i class="fa fa-spinner fa-4x fa-spin"></i></center>');
  $('#client_details').modal('show'); 

  $.post("ajax_client_details.php",
  {
    client_id: ids,
  },
  function(data, status){
    $('#client_details_div').html(data);
    //alert("Data: " + data + "\nStatus: " + status);
  });


}


</script>

