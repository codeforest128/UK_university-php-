<?php


header("Access-Control-Allow-Origin: *");




	include('../../classes/DB.php');
	include('../../classes/login.php');
	
    if (!Login::isAdminLoggedIn()) {
         header("Location: login.php");
		}



		if (isset($_COOKIE['SNID']))	{			
			$token = $_COOKIE['SNID'];
			$admin_id = DB::query('SELECT admin_id FROM admin_login_tokens WHERE token=:token', array(':token'=>sha1($token)))[0]['admin_id'];

			
		}
		
		
		if(array_key_exists('logout',$_POST)){
			  DB::query('DELETE FROM admin_login_tokens WHERE admin_id=:admin_id', array(':admin_id'=>Login::isAdminLoggedIn()));
			  header("Location: login.php");
		}


$client_id = $_POST['client_id'];

$clients_details = DB::query('SELECT * FROM client_details WHERE client_id="'.$client_id.'"');	

?>


<?php
foreach ($clients_details as $keyCli => $valueCli) {
?>


<div class="row">
	<div class="col">Contact name</div>
	<div class="col"><?php echo $valueCli['contact_name'];?></div>
</div>
<div class="row">
	<div class="col">Contact Email</div>
	<div class="col"><?php echo $valueCli['contact_email'];?></div>
</div>
<div class="row">
	<div class="col">Contact Telephone</div>
	<div class="col"><?php echo $valueCli['contact_tel'];?></div>
</div>
<div class="row">
	<div class="col">Company Name</div>
	<div class="col"><?php echo $valueCli['company_name'];?></div>
</div>
<div class="row">
	<div class="col">All Email</div>
	<div class="col"><?php echo $valueCli['all_email'];?></div>
</div>
<div class="row">
	<div class="col">Note</div>
	<div class="col"><?php echo $valueCli['note'];?></div>
</div>
<div class="row">
	<div class="col">Creation Date</div>
	<div class="col"><?php echo $valueCli['created_at'];?></div>
</div>
<?php
}
?>