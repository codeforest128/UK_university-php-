$(document).ready(function() {
  $('#header').load('/header.html');
  $('#footer').load('/footer.html');
});

