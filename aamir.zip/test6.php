<?php
/*  include_once "../classes/DB.php";
    $smtp_details = array("account" => "george@oxbridgecareershub.co.uk", "pass" => "Osiris60");
    $from_name = "OCH George";
    $subject = "Generalised SMTP Test - OCH";
    $message = "<h1 style='color: red'>Hey There!</h1><p>This is an SMTP TEST wrapped message?</p>";
    $to = array("georgeb.cherry@gmail.com", "george.cherry@st-hughs.ox.ac.uk");
    mailer_man($smtp_details, $from_details, $subject, $message, $to); */
?>