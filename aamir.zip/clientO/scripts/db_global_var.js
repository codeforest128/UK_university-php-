var latest_selected_candidate_id = "";
var selected_candidate_ids = [];
var stu_offset = 0;
var total_selection_size;
var max_results = 25;
var sel_type = "all";
var block_sel_candidate = false;
var use_filters = true;