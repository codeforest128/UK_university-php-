<div class="formrow"> 
    <label class="checklabel" for="career-check">Career</label>
    <input class="checkbox1" type="checkbox" name="career" id="career-check">
</div>
<div class="formrow">
    <label class="checklabel" for="intern-check">Internship</label>
    <input class="checkbox1" type="checkbox" name="intern" id="intern-check">
</div>