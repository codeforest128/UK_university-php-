<form action="" method="POST">
    <input type="hidden" name="search-type" value="basic"/>
    <?php
        include_once "formblock/opp_type.php";
        include_once "formblock/dropdowns.php";
        include_once "formblock/submit_search.php";
    ?>
</form>