<?php
    include_once "../../classes/DB.php";
?>
<!DOCTYPE html>
<?php
    $title = "Contact Us";
    include_once "../dev/websitedraft/web/components/header.php";
?>
<body>
    <?php
        include_once "components/clientnav.php";
    ?>
    <div style="height: 70%;">
        <h1 style="color: purple;">TEST CONTENT</h1>
    </div>
    <?php
        include_once "../dev/websitedraft/web/components/footer.php";
    ?>
</body>