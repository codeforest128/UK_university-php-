<div class="filtersec">
    <p style="font-size:16px;font-weight:bold">Skills</p>
    <button type="button" class="dd_box" onclick="selectDropDown(event, 'skills_dd', '<?php echo $search_type; ?>'); return false;"><p id="skill_filter_total_<?php echo $search_type; ?>" class="total_button_text">0 skills </p> selected</button>
    <div class="dd_content" id="skills_dd_<?php echo $search_type; ?>">
        <input type="text" class="dd_search" id="skills_input_<?php echo $search_type; ?>" onkeyup="filterDropDown(event)" placeholder="Search for names..">
        <ul class="dd_ul" id="skills_ul_<?php echo $search_type; ?>">
            <?php
                $skill_set_file = file_get_contents("../../temp/skill_set.csv");
                $skill_set = explode(",", $skill_set_file);
                for ($i = 0; $i < sizeof($skill_set); $i++) {
                    $c_skill = ltrim(rtrim($skill_set[$i]));
                    if ($c_skill == "") {
                        continue;
                    }
                    echo "<li><label style='display: inline;'><input onchange='update_filter_total(event)' type='checkbox' style='display: inline;' name='skill-" . strtolower($c_skill) . "'>" . ucfirst($c_skill) . "</label></li>";
                }
            ?>
        </ul>
    </div>
</div>
<div class="filtersec">
    <p style="font-size:16px;font-weight:bold">Courses</p>
    <button type="buttton" class="dd_box" onclick="selectDropDown(event, 'courses_dd', '<?php echo $search_type; ?>'); return false;"><p id="course_filter_total_<?php echo $search_type; ?>" class="total_button_text">0 courses </p> selected</button>
    <div class="dd_content" id="courses_dd_<?php echo $search_type; ?>">
        <input type="text" class="dd_search" id="courses_input_<?php echo $search_type; ?>" onkeyup="filterDropDown(event)" placeholder="Search for names..">
        <ul class="dd_ul" id="courses_ul_<?php echo $search_type; ?>">
            <?php
                $course_set = DB::query("SELECT DISTINCT `course` FROM `posts`", null);
                $fixed_course_set = array();
                for ($i = 0; $i < sizeof($course_set); $i++) {
                    $fixed_course_set[$i] = $course_set[$i]["course"];
                }
                sort($fixed_course_set);
                for ($i = 0; $i < sizeof($fixed_course_set); $i++) {
                    $c_course = $fixed_course_set[$i];
                    if ($c_course == "") {
                        continue;
                    }
                    echo "<li><label style='display: inline;'><input onchange='update_filter_total(event)' type='checkbox' style='display: inline;' name='course-" . $c_course . "'>" . $c_course . "</label></li>";
                }
            ?>
        </ul>
    </div>
</div>
<div class="filtersec">
    <p style="font-size:16px;font-weight:bold">Grades</p>
    <button type="buttton" class="dd_box" onclick="selectDropDown(event, 'grades_dd', '<?php echo $search_type; ?>'); return false;"><p id="grade_filter_total_<?php echo $search_type; ?>" class="total_button_text">0 grades </p> selected</button>
    <div class="dd_content" id="grades_dd_<?php echo $search_type; ?>">
        <input type="text" class="dd_search" id="grades_input_<?php echo $search_type; ?>" onkeyup="filterDropDown(event)" placeholder="Search for names..">
        <ul class="dd_ul" id="grades_ul_<?php echo $search_type; ?>">
            <li><label style='display: inline;'><input type='checkbox' onchange='update_filter_total(event)' style='display:inline;' name="grade-1st">1st</label></li>
            <li><label style='display: inline;'><input type='checkbox' onchange='update_filter_total(event)' style='display:inline;' name="grade-2:1">2:1</label></li>
            <li><label style='display: inline;'><input type='checkbox' onchange='update_filter_total(event)' style='display:inline;' name="grade-2:2">2:2</label></li>
            <li><label style='display: inline;'><input type='checkbox' onchange='update_filter_total(event)' style='display:inline;' name="grade-3rd">3rd</label></li>
        </ul>
    </div>
</div>
<div class="filtersec">
    <p style="font-size:16px;font-weight:bold">Sectors</p>
    <button type="buttton" class="dd_box" onclick="selectDropDown(event, 'sectors_dd', '<?php echo $search_type; ?>'); return false;"><p id="sector_filter_total_<?php echo $search_type; ?>" class="total_button_text">0 sectors </p> selected</button>
    <div class="dd_content" id="sectors_dd_<?php echo $search_type; ?>">
        <input type="text" class="dd_search" id="sectors_input_<?php echo $search_type; ?>" onkeyup="filterDropDown(event)" placeholder="Search for names..">
        <ul class="dd_ul" id="sectors_ul_<?php echo $search_type; ?>">
            <?php
                foreach ($SECTORS as $sector) {
                    echo "<li><label style='display: inline;'><input type='checkbox' onchange='update_filter_total(event)' style='display: inline;' name='sector-" . $sector . "'>" . $sector . "</label></li>";
                }
            ?>
        </ul>
    </div>
</div>
<div class="filtersec">
    <p style="font-size:16px;font-weight:bold">Graduation year</p>
    <button type="buttton" class="dd_box" onclick="selectDropDown(event, 'grad_dd', '<?php echo $search_type; ?>'); return false;"><p id="gradyear_filter_total_<?php echo $search_type; ?>" class="total_button_text">0 years </p> selected</button>
    <div class="dd_content" id="grad_dd_<?php echo $search_type; ?>">
        <input type="text" class="dd_search" id="grad_input_<?php echo $search_type; ?>" onkeyup="filterDropDown(event)" placeholder="Search for names..">
        <ul class="dd_ul" id="grad_ul_<?php echo $search_type; ?>">
            <?php
                $c_year = date("Y") + 1;
                for ($i = 0; $i < 3; $i++) {
                    $t_year = $c_year + $i;
                    echo "<li><label style='display: inline;'><input type='checkbox' onchange='update_filter_total(event)' style='display:inline;' name='gradyear-" . $t_year ."'>"
                       . $t_year ."</label></li>";
                }
            ?>
        </ul>
    </div>
</div>
<script src='scripts/aesthetic/search_dropdowns.js'></script>