<div class="filtersec">
    <p style="font-size:16px;font-weight:bold">Keyword search</p>
    <input type="text" class="keyword" name="keywords" placeholder="e.g. neural net, machine learning, etc..." style="text-indent: 5px;">
</div>
<div class="filtersec">
    <p style="font-size:16px;font-weight:bold">Amount of candidates to display</p>
    <select name="amount_required" class="form-control">
        <option value='5'>5</option>
        <option value='10'>10</option>
        <option value='15'>15</option>
        <option value='20'>20</option>
        <option value='25'>25</option>
    </select>
</div>