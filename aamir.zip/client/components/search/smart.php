<form action="" method="POST">
    <input type="hidden" name="search-type" value="smart"/>
    <?php
        $search_type = "smart";
        include "formblock/opp_type.php";
        include "formblock/smart_additions.php";
        include "formblock/dropdowns.php";
        include "formblock/submit_search.php";
    ?>
</form>