<nav class="navbar navbar-light navbar-expand-lg fixed-top bg-white clean-navbar">
    <div class="container-fluid" ><a class="logo" href="index.php"><img src="../logo.png" height="12%"></a><button class="navbar-toggler" data-toggle="collapse" data-target="#navcol-1"><span class="sr-only">Toggle navigation</span><span class="navbar-toggler-icon"></span></button>
        <div class="collapse navbar-collapse"
            id="navcol-1">
            <ul class="nav navbar-nav ml-auto">
                <li class="nav-item" role="presentation"><a class="nav-link" href="account.php">My Account</a></li>
                <li class="nav-item" role="presentation"><a class="nav-link" href="database.php">Database</a></li>
                <li class="nav-item" role="presentation"> <form method="post">
				    <input value="Logout" name="logout" style="background-color:white;border:none" type="submit" class="nav-link text-primary"><!--<span><i class="fas fa-sign-out-alt logout-icon"></i></span>--></form>
			    </li>
            </ul>
        </div>
    </div>
</nav>