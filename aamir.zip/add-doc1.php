<?php
    include_once "../classes/DB.php";
    include_once "../classes/login.php";
    include_once "arrays.php";
    
    if (!Login::isLoggedIn()) {
        header("Location: login.php");
        exit;
    }
    
    if (isset($_COOKIE['SNID']))	{			
        $token = $_COOKIE['SNID'];
		$userid = DB::query('SELECT user_id FROM login_tokens WHERE token=:token', array(':token'=>sha1($token)))[0]['user_id'];
    }
    
    // Get basic information for autopopulating the form
    $sql = "SELECT firstname, lastname, mob, ethnicity, nationality, gender, school, qualification, course, college, course_end, location, ind1, ind2, type, `availability`, hear, descr, grade "
         . "FROM `posts` "
         . "WHERE user_id=:uid";
    $init_details = DB::query($sql, array(":uid" => $userid))[0];
    
    $sectors = array("Account Management", "Accounting & Tax", "Analyst", "Compliance", "Consulting & Strategy", "Customer Service", "Design", "Engineering", "Finance", "Information Technology", "Legal", "Marketing", "Media", "Medical", "Operations", "Project Management ", "Protective Services", "Talent acquisition", "Research", "Sales", "Software Engineering", "I'm flexible / Open to all roles");

    $kind = array("Accountancy/Professional Services", "Automotive & Transport", "Banking & Finance", "Charity & Public Sector", "Consulting", "Consumer & Retail", "Energy", "Engineering & Industrial", "FMCG", "Hospitality", "HR", "Law", "Marketing & Media", "Property and Construction", "Recruitment", "Supply Chain & Logistics", "Technology", "Telecoms ", "Other Sectors", "All Sectors");
    
    $sql = "SELECT email "
         . "FROM `users` "
         . "WHERE id=:uid";
    $email = DB::query($sql, array(":uid" => $userid))[0]["email"];
    
    $sql = "SELECT `email` "
         . "FROM `altemail` "
         . "WHERE student_id=:uid";
    $altemail = DB::query($sql, array(":uid" => $userid))[0]["email"];

    if (strpos($email, '.ox.ac.uk') !== false) {
        $courses = $ox_courses;
        $colleges = $ox_colleges;
        $university = "University of Oxford";
    } else if (strpos($email, '.cam.ac.uk') !== false) {
        $courses = $cam_courses;
        $colleges = $cam_colleges;
        $university = "University of Cambridge";
    } else if (strpos($email, 'durham.ac.uk') !== false) {
        $courses = $dur_courses;
        $colleges = $dur_colleges;
        $university = "University of Durham";
    } else if (strpos($email, 'imperial.ac.uk') !== false) {
        $courses = $imp_full_courses;
        $university = "Imperial College London";
        $colleges = array();
    } else if (strpos($email, "lse.ac.uk") !== false) {
        $courses = $lse_full_courses;
        $university = "London School of Economics";
        $colleges = array();
    } else if (strpos($email, 'ucl.ac.uk') !== false) {
        $courses = $ucl_full_courses;
        $university = "University College London";
        $college = array();
    }

    $statusMsg = "";
    if (isset($_POST["firstname"])) {

        $path = '../temp/uploads/';

        if ($_FILES["userfile"]["error"] > 0) {
            $statusMsg = "File upload failed, please try again.";
        } else {
            $f_name = $_FILES["userfile"]["name"];
            $ext = end(explode(".", $f_name)); # extra () to prevent notice
            if ($ext == "pdf" || $ext == "doc" || $ext == "docx") {
                $f_name = 'OCH' . $userid . ' ' . $username . ' CV.' . $ext;
                move_uploaded_file($_FILES['userfile']['tmp_name'], $path . $f_name);
                // $data['image_url'] = $path.$f_name;
                $insert = DB::query('INSERT into images VALUES (\'\', :file_name, NOW(), :userid, \'\')', array(':file_name' => $f_name, ':userid' => $userid));
                if ($ext == "pdf") {
                    $f_name = 'OCH' . $userid . ' ' . $username . ' CV.' . $ext;
                    move_uploaded_file($_FILES['userfile']['tmp_name'], "../temp/cvs_pdf_form/" . $f_name);
                }
            } else {
                $statusMsg = "We only accept Word Documents or PDFs for CV files";
            }
        }
        
        $firstname = $_POST['firstname'];
        $lastname = $_POST['lastname'];
        $mob = $_POST['mob'];
        $ethnicity = $_POST['ethnicity'];
        $nationality = $_POST['nationality'];
        $gender = $_POST['gender'];
        $school = $_POST['school'];
        $qualification = $_POST['qualification'];
        $college = $_POST['college'];
        $course = $_POST['course'];
        $course_end = $_POST['course_end'];
        $location = $_POST['location'];
        $type = $_POST['type'];
        $hear = $_POST['hear'];
        $descr = nl2br(strip_tags($_POST['descr']));
        $grade = $_POST['grade'];
        $availability = $_POST['availability'];
        $emailref = $_POST['emailref'];
        $altemail = $_POST['altemail'];
        $sectors = json_encode($_POST['sector']);
        $kind = json_encode($_POST['kind']);
        $loggedInUserId = Login::isLoggedIn();
        
        if ($loggedInUserId == $userid) {
            $sql = "UPDATE `posts` SET "
                 . "`firstname`=:firstname, "
                 . "`lastname`=:lastname, "
                 . "`mob`=:mob, "
                 . "`ethnicity`=:ethnicity, "
                 . "`nationality`=:nationality, "
                 . "`gender`=:gender, "
                 . "`school`=:school, "
                 . "`qualification`=:qualification, "
                 . "`course`=:course, "
                 . "`college`=:college, "
                 . "`course_end`=:course_end, "
                 . "`location`=:location, "
                 . "`ind1`=:ind1, "
                 . "`ind2`=:kind, "
                 . "`type`=:type, "
                 . "`availability`=:availability, "
                 . "`hear`=:hear, "
                 . "`descr`=:descr, "
                 . "`grade`=:grade "
                 . "WHERE `user_id`=:userid";
            DB::query($sql, array(':college' => $college, ':course' => $course, ':userid' => $userid, ':course_end' => $course_end, ':ind1' => $sectors, ':kind' => $kind, ':firstname' => $firstname, ':lastname' => $lastname, ':mob' => $mob, ':ethnicity' => $ethnicity, ':nationality' => $nationality, ':gender' => $gender, ':school' => $school, ':qualification' => $qualification, ':location' => $location, ':availability' => $availability, ':type' => $type, ':hear' => $hear, ':descr' => $descr, ':grade' => $grade));
            if ($altemail != "") {
                DB::query('INSERT INTO altemail VALUES (\'\', :userid, :emailref, 0)', array(':userid' => $userid, ':emailref' => $altemail));
            }
            if ($emailref != "") {
                if (!DB::query('SELECT emailref FROM emailref WHERE emailref=:emailref', array(':emailref' => $emailref))) {
                    if (!DB::query('SELECT email FROM users WHERE email=:email', array(':email' => $emailref))) {

                        DB::query('INSERT INTO emailref VALUES (\'\', :userid, :emailref, NOW())', array(':userid' => $userid, ':emailref' => $emailref));
                        
                        $from = $email; //"u659159300@srv134.main-hosting.eu";
                        $to =  $emailref;
                        $subject = $_POST['firstname'] . ' ' . $_POST['lastname'] . ' has invited you to sign up to OCH';
                        $message = '<html><p>Dear Student,</p><br/><p> ' . $_POST['firstname'] . ' ' . $_POST['lastname'] . ' has invited you to join the OCH community. Sign up to Oxbridge Careers Hub now and employers will contact you directly with internship and career opportunities! </p><br/><br/><strong><p>To sign up, click <a href="https://www.oxbridgecareershub.co.uk/signup.php">here</a>. If you have any questions then please get in touch <a href="https://www.oxbridgecareershub.co.uk/contact-us.php">here</a>. </p></strong><br/><p>Thank you,</p><br/><p>Oxbridge Careers Hub Team</p></html>';
                        $headers = "MIME-Version: 1.0" . "\r\n";
                        $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
                        $headers .= "From:" . $from . "\r\n";

                        mail($to, $subject, $message, $headers);

                    }
                }
            }

            DB::query('DELETE FROM posts WHERE user_id=:userid AND firstname="" ', array(':userid' => $userid));
            $_SESSION['flash'] = '<div class="text-center"><b>Thank you for joining Oxbridge Careers Hub, we’re excited to have you on the site! Please check your emails and confirm your email address to activate your account. Please also like our Facebook and LinkedIn for our latest updates.</b></div><br/><div class="text-center"><a style="margin-right: 0.5em;" href="https://www.facebook.com/oxfordcareershub/" class="fa fa-facebook"></a><a style="margin-left: 0.5em;" href="https://www.linkedin.com/company/oxford-careers-hub/about/" class="fa fa-linkedin"></a></div>';
            //<a class="btn btn-primary " style="background-color: #3B5998;color:white;"><i class="fab fa-facebook-f"></i><a>
            header("Location: account.php");
        } else {
            echo "Not logged in";
        }
   }
?>

<!DOCTYPE html>
<html>
    <?php
        $title = "Add Details";
        include_once "components/header.php";
    ?>
<body>
    <?php
        include_once "components/simple_navbar.php";
    ?>
<div>
    <form autocomplete="off" id="regForm" name="regForm" method="post" enctype="multipart/form-data">
        <div class="tab" style="color:black;">
            <h1 class="tab-title">Tell us more about yourself</h1>
            <input type="text" placeholder="First Name" value="<?php echo $init_details["firstname"]; ?>" name="firstname" oninput="this.className = ''">
            <input type="text" placeholder="Last Name" value="<?php echo $init_details["lastname"]; ?>" name="lastname" oninput="this.className = ''">
            <input type="tel" placeholder="Phone number *" value="<?php echo $init_details["mob"]; ?>" name="mob" oninput="this.className = ''">
            <input type="email" placeholder="Alternative email (required)*" value="<?php echo $altemail; ?>" name="altemail" oninput="this.className = ''">

            <p class="label" style="color:#2980ef">Ethnicity</p>
            <?php
                $ethnicities = array("White" => array("White English", "White Welsh", "White Scottish", "White Northern Irish", "White Irish", "White Gypsy or Irish Traveller", "White Other"), "Mixed or Multiple ethnic groups" => array("Mixed White and Black Caribbean", "Mixed White and Black African", "Mixed White Other"), "Asian" => array("Asian Indian", "Asian Pakistani", "Asian Bangladeshi", "Asian Chinese", "Asian Other"), "Black" => array("Black African", "Black African American", "Black Caribbean", "Black Other"), "Other ethnic groups" => array("Arab", "Hispanic", "Latino", "Native American", "Pacific Islander", "Other", "Prefer not to say"));
            ?>
            <select name="ethnicity" id="ethnicity">
                <option>Select</option>
                <?php
                    $optgroup_html = "";
                    foreach ($ethnicities as $eg => $egl) {
                        $optgroup_html = "<optgroup label='" . $eg . "'>";
                        foreach ($egl as $egs) {
                            $optgroup_html .= "<option value='" . $egs . "'";
                            if ($egs == $init_details["ethnicity"]) {
                                $optgroup_html .= " selected";
                            }
                            $optgroup_html .= ">";
                            switch ($egs) {
                                case "White Other":
                                    $optgroup_html .= "Any other White background";
                                    break;
                                case "Mixed White Other":
                                    $optgroup_html .= "Any other Mixed or Multiple background";
                                    break;
                                case "Asian Other":
                                    $optgroup_html .= "Any other Asian background";
                                    break;
                                case "Black Other":
                                    $optgroup_html .= "Any other Black background";
                                    break;
                                case "Other":
                                    $optgroup_html .= "Any other ethnic group";
                                    break;
                                case "Arab":
                                case "Hispanic":
                                case "Latino":
                                case "Native American":
                                case "Pacific Islander":
                                case "Prefer not to say":
                                    $optgroup_html .= $egs;
                                    break;
                                default:
                                    $optgroup_html .= ltrim(strstr($egs, " "));
                                    break;
                            }
                            $optgroup_html .= "</option>";
                        }
                        $optgroup_html .= "</optgroup>";
                        echo $optgroup_html;
                    }
                ?>
            </select>
            <p style="color:#2980ef" class="label">Nationality</p>
            <?php
                $nationalities = array("Afghan", "Albanian", "Algerian", "American", "Andorran", "Angolan", "Antiguans", "Argentinean", "Armenian", "Australian", "Austrian", "Azerbaijani", "Bahamian", "Bahraini", "Bangladeshi", "Barbadian", "Barbudans", "Batswana", "Belarusian", "Belgian", "Belizean", "Beninese", "Bhutanese", "Bolivian", "Bosnian", "Brazilian", "British", "Bruneian", "Bulgarian", "Burkinabe", "Burmese", "Burundian", "Cambodian", "Cameroonian", "Canadian", "Cape Verdean", "Central African", "Chadian", "Chilean", "Chinese", "Colombian", "Comoran", "Congolese", "Costa rican", "Croatian", "Cuban", "Cypriot", "Czech", "Danish", "Djibouti", "Dominican", "Dutch", "East Timorese", "Ecuadorean", "Egyptian", "Emirian", "Equatorial Guinean", "Eritrean", "Estonian", "Ethiopian", "Fijian", "Filipino", "Finnish", "French", "Gabonese", "Gambian", "Georgian", "German", "Ghanaian", "Greek", "Grenadian", "Guatemalan", "Guinea-Bissauan", "Guinean", "Guyanese", "Haitian", "Herzegovinian", "Honduran", "Hungarian", "Icelander", "Indian", "Indonesian", "Iranian", "Iraqi", "Irish", "Israeli", "Italian", "Ivorian", "Jamaican", "Japanese", "Jordanian", "Kazakhstani", "Kenyan", "Kittian and Nevisian", "Kuwaiti", "Kyrgyz", "Laotian", "Latvian", "Lebanese", "Liberian", "Libyan", "Liechtensteiner", "Lithuanian", "Luxembourger", "Macedonian", "Malagasy", "Malawian", "Malaysian", "Maldivan", "Malian", "Maltese", "Marshallese", "Mauritanian", "Mauritian", "Mexican", "Micronesian", "Moldovan", "Monacan", "Mongolian", "Moroccan", "Mosotho", "Motswana", "Mozambican", "Namibian", "Nauruan", "Nepalese", "New Xealander", "Ni-Vanuatu", "Nicaraguan", "Nigerien", "North korean", "Northern irish", "Norwegian", "Omani", "Pakistani", "Palauan", "Panamanian", "Papua New Guinean", "Paraguayan", "Peruvian", "Polish", "Portuguese", "Qatari", "Romanian", "Russian", "Rwandan", "Saint Lucian", "Salvadoran", "Samoan", "San Marinese", "Sao Tomean", "Saudi", "Scottish", "Senegalese", "Serbian", "Seychellois", "Sierra Leonean", "Singaporean", "Slovakian", "Slovenian", "Solomon Islander", "Somali", "South african", "South korean", "Spanish", "Sri lankan", "Sudanese", "Surinamer", "Swazi", "Swedish", "Swiss", "Syrian", "Taiwanese", "Tajik", "Tanzanian", "Thai", "Togolese", "Tongan", "Trinidadian or Tobagonian", "Tunisian", "Turkish", "Tuvaluan", "Ugandan", "Ukrainian", "Uruguayan", "Uzbekistani", "Venezuelan", "Vietnamese", "Welsh", "Yemenite", "Zambian", "Zimbabwean");
            ?>
            <select name="nationality">
                <?php
                    $def_nat = "British";
                    if ($init_details["nationality"] != "") {
                        $def_nat = $init_details["nationality"];
                    }
                    $opt_html = "";
                    foreach ($nationalities as $n) {
                        $opt_html = "<option value='" . $n . "'";
                        if ($n == $def_nat) {
                            $opt_html .= " selected";
                        }
                        $opt_html .= ">" . $n . "</option>";
                        echo $opt_html;
                    }
                ?>
            </select>
            <p style="color:#2980ef" class="label">Gender</p>
            <?php
                $genders = array("Male", "Female", "Non-binary/other", "Prefer not to say");
            ?>
            <select name="gender" id="gender">
                <option>Select</option>
                <?php
                    foreach ($genders as $g) {
                        $opt_html = "<option value='" . $g . "'";
                        if ($g == $init_details["gender"]) {
                            $opt_html .= " selected";
                        }
                        $opt_html .= ">" . $g . "</option>";
                        echo $opt_html;
                    }
                ?>
            </select>
        </div>

        <div class="tab" style="color:black">
            <h1 class="tab-title">Education</h1>
            <p style="color:#2980ef" class="label">Secondary Education</p>
            <input placeholder="Secondary Education" value="<?php echo $init_details["school"]; ?>" type="text" name="school" oninput="this.className = ''">
            <p style="color:#2980ef" class="label">University</p>
            <input value="<?php echo $university; ?>" type="text" disabled>
            <?php
                if ($university == "University of Oxford" || $university == "University of Cambridge" || $university == "University of Durham") {
            ?>
            <p style="color:#2980ef" class="label">College</p>
            <select name="college" id="college">
                <option value="">Select College</option>
                <?php 
                    $list_html = "";
                    foreach ($colleges as $college) {
                        $list_html =    '<option';
                        if ($college == $init_details["college"]) {
                            $list_html .= " selected";
                        }
                        $list_html .=   '>' . $college . '</option>';
                        echo $list_html;
                    } 
                ?>
            </select>
            <?php
                } else {
            ?>
            <input type="hidden" name="college" value="N.A."/>
            <?php
                }
            ?>
            <p style="color:#2980ef" class="label">Qualification</p>
            <?php
                $qualifications = array("Bachelor's", "Integrated Master's", "Postgraduate Master's", "MBA", "Doctoral");
            ?>
            <select name="qualification" selected="<?php echo $init_details["qualification"]; ?>" id="qualification">
                <?php
                    $opt_html = "";
                    foreach ($qualifications as $q) {
                        $opt_html = "<option value='" . $q . "'";
                        if ($q == $init_details["qualification"]) {
                            $opt_html .= " selected";
                        }
                        $opt_html .= ">" . $q . "</option>";
                        echo $opt_html;
                    }
                ?>
            </select>
            <p style="color:#2980ef" class="label">Grade (predicted/achieved)</p>
            <?php
                $grades = array("1st", "2:1", "2:2", "3rd", "Fail");
            ?>
            <select name="grade" selected="<?php echo $init_details["grade"]; ?>" id="grade">
                <?php
                    $opt_html = "";
                    foreach ($grades as $g) {
                        $opt_html = "<option value='" . $g . "'";
                        if ($g == $init_details["grade"]) {
                            $opt_html .= " selected";
                        }
                        $opt_html .= ">" . $g . "</option>";
                        echo $opt_html;
                    }
                ?>
            </select>
            <p style="color:#2980ef" class="label">Course</p>
            <select name="course" selected="<?php echo $init_details["course"]; ?>" id="course">
                <?php
                    $list_html = "";
                    foreach ($courses as $c) {
                        $list_html = '<option value="' . $c . '"';
                        if ($c == $init_details["course"]) {
                            $list_html .= " selected";
                        }
                        $list_html .= '>' . $c . '</option>';
                        echo $list_html;
                    }
                ?>
            </select>
            <p style="color:#2980ef" class="label">Graduation year</p>
            <br/>
            <input type="number" value="<?php 
                $val = Date("Y");
                if ($init_details["course_end"] != 0) {
                    $val = $init_details["course_end"];   
                }
                echo $val;
            ?>" name="course_end" min="1990" max="2025" step="1" style="width: 20%; color: black;" oninput="this.className = ''">
        </div>

        <div class="tab" style="color:black">
            <h1 class="tab-title">Aspirations</h1>
            <p style="color:#2980ef" class="label">Where are you hoping to work?</p>
            <?php
                $locations = array("Nationwide", "North East England", "North West England", "Northern Ireland", "Scotland", "South East England", "South West England", "Wales", "West Midlands", "Yorkshire and the Humber", "East Midlands", "East of England", "Greater London", "International", "London");
            ?>
            <select name="location" id="location">
                <?php 
                    $opt_html = "";
                    foreach ($locations as $l) {
                        $opt_html = "<option value='" . $l . "'";
                        if ($l == $init_details["location"]) {
                            $opt_html .= " selected";
                        }
                        $opt_html .= ">" . $l . "</option>";
                        echo $opt_html;
                    }
                ?>
            </select>
            <p style="color:#2980ef" class="label">What kind of work would you like to do on a daily basis?</p>
            <div class="container option-container">
                <label class="text-danger" id="msg_ind1"></label>
                <ul class="ks-cboxtags">
                    <?php 
                        $list_html = "";
                        $int_sectors = json_decode($init_details["ind1"]);
                        foreach ($sectors as $sector) {
                            $list_html = '<li><input type="checkbox" class="ind1" name="sector[]" id="' . $sector . '" value="' . $sector . '"';
                            if (in_array($sector, $int_sectors)) {
                                $list_html .= ' checked';
                            }
                            $list_html .= '><label for="' . $sector . '">' . $sector . '</label></li>';
                            echo $list_html;
                        }
                    ?>
                </ul>
            </div>
            <p style="color:#2980ef" class="label">Which Sectors are you interested in?</p>
            <div class="container option-container">
                <label class="text-danger" id="msg_ind2"></label>
                <ul class="ks-cboxtags">
                    <?php 
                        $list_html = "";
                        $int_kinds = json_decode($init_details["ind2"]);
                        foreach ($kind as $kinds) {
                            $list_html = '<li><input type="checkbox" class="ind2" name="kind[]" id="' . $kinds . '" value="' . $kinds . '"';
                            if (in_array($kinds, $int_kinds)) {
                                $list_html .= ' checked';
                            }
                            $list_html .= '><label for="' . $kinds . '">' . $kinds . '</label></li>';
                            echo $list_html;
                        }
                    ?>
                </ul>
            </div>
            <p style="color:#2980ef" class="label">What kind of job?</p>
            <select name="type" selected="<?php echo $init_details["type"]; ?>" id="type">
                <option value="Career">Career</option>
                <option value="Internship">Internship</option>
                <option value="Both">Both</option>
            </select>
            <p style="color:#2980ef" class="label"> What makes you suitable to work in these sectors?</p>
            <textarea class="form-control" value="<?php echo $init_details["descr"]; ?>" rows="4" id="describe" name="descr" placeholder="(Optional but recommended)" maxlength="300"></textarea>
            <p style="color:#2980ef" class="label">When can you start?</p>
            <input type="date" name="availability" value="<?php if ($init_details["availability"] == 0) { echo "2020-07-01"; } else { echo $init_details["availability"]; }?>"/>
        </div>

        <div class="tab" style="color:black">
            <?php
                if ($init_details["school"] == "") {
            ?>
            <h1 class="tab-title"> Upload CV and submit</h1>
            <input type="file" class="btn btn-primary btn-final-tab" name="userfile" id="fileToUpload">
            <p style="color:black" class="label">How did you hear about us?</p>
            <select name="hear" required>
                <option value="">Select one from these options</option>
                <option>Google search</option>
                <option>College ambassador</option>
                <option>Facebook</option>
                <option>LinkedIn</option>
                <option>Friend/family</option>
                <option>Society ambassador</option>
                <option>Other</option>
            </select>
            <p style="font-size: 14px; color: black; margin-bottom: 5px;" class="label">I agree to Oxbridge Careers Terms of Use and Privacy Policy</p>
            <br/>
            <p style="font-size: 12px; color: black; white-space: normal; text-align: left; margin-top: 2%; word-wrap: break-word;" class="label">I agree to Oxbridge Careers Hub <a target="_blank" href="TermsofUse.pdf">Terms of Use</a> and <a target="_blank" href="Privacypolicy.pdf">Privacy Policy</a>. I also agree to the distribution and use of my CV and data as agreed in the Terms of Use, please read the terms of Use to find out more about how we use your CV and personal data.</p>
            <div class="form-check">
                <input class="form-check-input" type="checkbox" required id="formCheck-1">
                <label class="form-check-label" for="formCheck-1">Accept our T&amp;Cs</label>
            </div>
            <input class="btn btn-primary btn-block submit" type="submit" method="post" name="post" value="Submit">
            <?php
                } else {
            ?>
                <input class="btn btn-primary btn-block submit" type="submit" method="post" name="post" value="Update Account">
            <?php
                }
            ?>
        </div>
        
        <div class="form-continuation">
            <div style="float:right;">
                <button class="btn btn-primary btn-block" type="button" style="border:none;" id="nextBtn" onclick="nextPrev(1)">Next</button>
            </div>
            <div style="float:left;">
                <button class="btn btn-primary btn-block" type="button" style="border:none;background-color:grey;opacity:0.5;" id="prevBtn" onclick="nextPrev(-1)">Previous</button>
            </div>
        </div>

        <!-- Circles which indicates the steps of the form: -->
        <div style="text-align:center;margin-top:40px;">
            <span class="step"></span>
            <span class="step"></span>
            <span class="step"></span>
            <span class="step"></span>
        </div>
    </form>
</div>
<style>
    /* Style the form */
    body {
        background-color: white;
    }

    /*input[type="text"], textarea {

  background-color : #d1d1d1; 

}
input[type="tel"], textarea {

  background-color : #d1d1d1; 

}*/
    #regForm {
        background-color: inherit;
        ;
        margin: 50px auto;
        padding: 40px;
        width: 60%;
        min-width: 300px;
    }

    input,
    select {
        background: inherit;
        border: none;
        border-bottom: 1px solid #434a52;
        border-radius: 0;
        box-shadow: none;
        outline: none;
        color: inherit;
    }


    /* Style the input fields */
    input {
        padding: 10px;
        width: 60%;
        margin-left: 20%;
        font-size: 17px;
        font-family: Trebuchet MS;
    }

    select,
    select[multiple] {
        padding: 10px;
        margin-left: 20%;
        width: 60%;
        display: block;
        font-size: 17px;
        font-family: Trebuchet MS;
        border: 1px solid #aaaaaa;
        color: inherit;
    }

    /* Mark input boxes that gets an error on validation: */
    input.invalid {
        background-color: #ffdddd;
    }

    /* Hide all steps by default: */
    .tab {
        display: none;
    }

    .label {
        margin-left: 20%;
        font-size: inherit;
        font-weight: inherit;
        font-family: inherit;
    }

    /* Make circles that indicate the steps of the form: */
    .step {
        height: 15px;
        width: 15px;
        margin: 0 2px;
        background-color: #2980ef;
        border: none;
        border-radius: 50%;
        display: inline-block;
        opacity: 1;
    }

    /* Mark the active step: */
    .step.active {
        opacity: 1;
    }

    /* Mark the steps that are finished and valid: */
    .step.finish {
        background-color: #4CAF50;


    }

    * {
        box-sizing: border-box;
    }


    /*the container must be positioned relative:*/
    .autocomplete {
        position: relative;
        display: inline-block;
    }


    .autocomplete-items {
        position: absolute;
        border: 1px solid #d4d4d4;
        border-bottom: none;
        border-top: none;
        z-index: 99;
        /*position the autocomplete items to be the same width as the container:*/
        top: 100%;
        left: 0;
        right: 0;
        background-color: white;

    }

    .autocomplete-items div {
        padding: 10px;
        cursor: pointer;
        color: inherit;
        border-bottom: 1px solid #d4d4d4;
    }

    /*when hovering an item:*/
    .autocomplete-items div:hover {
        background-color: grey;
    }

    /*when navigating through the items using the arrow keys:*/
    .autocomplete-active {
        background-color: DodgerBlue !important;
        color: #ffffff;
    }

    .container {
        max-width: 100%;

        font-size: 13px;
    }

    ul.ks-cboxtags {
        list-style: none;
    }

    ul.ks-cboxtags li {
        display: inline;
    }

    ul.ks-cboxtags li label {
        display: inline-block;
        background-color: rgba(255, 255, 255, .9);
        border: 2px solid rgba(139, 139, 139, .3);
        color: black;
        border-radius: 25px;
        white-space: nowrap;
        margin: 3px 0px;
        -webkit-touch-callout: none;
        -webkit-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        user-select: none;
        -webkit-tap-highlight-color: transparent;
        transition: all .2s;
    }

    ul.ks-cboxtags li label {
        padding: 8px 12px;
        cursor: pointer;
    }

    ul.ks-cboxtags li label::before {
        display: inline-block;
        font-style: normal;
        font-variant: normal;
        text-rendering: auto;
        -webkit-font-smoothing: antialiased;
        font-family: "Font Awesome 5 Free";
        font-weight: 900;
        font-size: 12px;
        padding: 2px 6px 2px 2px;
        content: "\f067";
        transition: transform .3s ease-in-out;
    }

    ul.ks-cboxtags li input[type="checkbox"]:checked+label::before {
        content: "\f00c";
        transform: rotate(-360deg);
        transition: transform .3s ease-in-out;
    }

    ul.ks-cboxtags li input[type="checkbox"]:checked+label {
        border: 2px solid #1bdbf8;
        background-color: #12bbd4;
        color: #fff;
        transition: all .2s;
    }

    ul.ks-cboxtags li input[type="checkbox"] {
        display: absolute;
    }

    ul.ks-cboxtags li input[type="checkbox"] {
        position: absolute;
        opacity: 0;
    }

    ul.ks-cboxtags li input[type="checkbox"]:focus+label {
        border: 2px solid #e9a1ff;
    }

    @media only screen and (max-width: 970px) {



        .label {
            margin-left: 0
        }

        select,
        input {
            width: 100%;
            margin-left: 0
        }

    }
</style>
<script>
    var currentTab = 0; // Current tab is set to be the first tab (0)
    showTab(currentTab); // Display the current tab

    function showTab(n) {
        // This function will display the specified tab of the form ...
        var x = document.getElementsByClassName("tab");
        x[n].style.display = "block";
        // ... and fix the Previous/Next buttons:
        if (n == 0) {
            document.getElementById("prevBtn").style.display = "none";
        } else {
            document.getElementById("prevBtn").style.display = "inline";
        }
        if (n == (x.length - 1)) {
            document.getElementById("nextBtn").style.display = "none";
        } else {
            document.getElementById("nextBtn").style.display = "inline";
            document.getElementById("nextBtn").innerHTML = "Next";
        }
        // ... and run a function that displays the correct step indicator:
        fixStepIndicator(n)
    }

    function nextPrev(n) {
        // This function will figure out which tab to display
        var x = document.getElementsByClassName("tab");
        // Exit the function if any field in the current tab is invalid:
        if (n == 1 && !validateForm()) return false;
        // Hide the current tab:
        x[currentTab].style.display = "none";
        // Increase or decrease the current tab by 1:
        currentTab = currentTab + n;
        // if you have reached the end of the form... :
        if (currentTab >= x.length) {
            //...the form gets submitted:
            document.forms["regForm"].submit();
            return false;
        }
        // Otherwise, display the correct tab:
        showTab(currentTab);
    }

    function validateForm() {
        // This function deals with validation of the form fields
        var x, y, i, valid = true;
        x = document.getElementsByClassName("tab");
        y = x[currentTab].getElementsByTagName("input");
        // A loop that checks every input field in the current tab:
        for (i = 0; i < y.length; i++) {
            // If a field is empty...
            if (y[i].value == "") {
                // add an "invalid" class to the field:
                y[i].className += " invalid";
                // and set the current valid status to false:
                valid = false;
            }
        }
        // If the valid status is true, mark the step as finished and valid:
        if (valid) {
            document.getElementsByClassName("step")[currentTab].className += " finish";
        }
        return valid; // return the valid status
    }

    function fixStepIndicator(n) {
        // This function removes the "active" class of all steps...
        var i, x = document.getElementsByClassName("step");
        for (i = 0; i < x.length; i++) {
            x[i].className = x[i].className.replace(" active", "");
        }
        //... and adds the "active" class to the current step:
        x[n].className += " active";
    }

    function autocomplete(inp, arr) {
        /*the autocomplete function takes two arguments,
        the text field element and an array of possible autocompleted values:*/
        var currentFocus;
        /*execute a function when someone writes in the text field:*/
        inp.addEventListener("input", function(e) {
            var a, b, i, val = this.value;
            /*close any already open lists of autocompleted values*/
            closeAllLists();
            if (!val) {
                return false;
            }
            currentFocus = -1;
            /*create a DIV element that will contain the items (values):*/
            a = document.createElement("DIV");
            a.setAttribute("id", this.id + "autocomplete-list");
            a.setAttribute("class", "autocomplete-items");
            /*append the DIV element as a child of the autocomplete container:*/
            this.parentNode.appendChild(a);
            /*for each item in the array...*/
            for (i = 0; i < arr.length; i++) {
                /*check if the item starts with the same letters as the text field value:*/
                if (arr[i].substr(0, val.length).toUpperCase() == val.toUpperCase()) {
                    /*create a DIV element for each matching element:*/
                    b = document.createElement("DIV");
                    /*make the matching letters bold:*/
                    b.innerHTML = "<strong>" + arr[i].substr(0, val.length) + "</strong>";
                    b.innerHTML += arr[i].substr(val.length);
                    /*insert a input field that will hold the current array item's value:*/
                    b.innerHTML += "<input type='hidden' value='" + arr[i] + "'>";
                    /*execute a function when someone clicks on the item value (DIV element):*/
                    b.addEventListener("click", function(e) {
                        /*insert the value for the autocomplete text field:*/
                        inp.value = this.getElementsByTagName("input")[0].value;
                        /*close the list of autocompleted values,
                        (or any other open lists of autocompleted values:*/
                        closeAllLists();
                    });
                    a.appendChild(b);
                }
            }
        });
        /*execute a function presses a key on the keyboard:*/
        inp.addEventListener("keydown", function(e) {
            var x = document.getElementById(this.id + "autocomplete-list");
            if (x) x = x.getElementsByTagName("div");
            if (e.keyCode == 40) {
                /*If the arrow DOWN key is pressed,
                increase the currentFocus variable:*/
                currentFocus++;
                /*and and make the current item more visible:*/
                addActive(x);
            } else if (e.keyCode == 38) { //up
                /*If the arrow UP key is pressed,
                decrease the currentFocus variable:*/
                currentFocus--;
                /*and and make the current item more visible:*/
                addActive(x);
            } else if (e.keyCode == 13) {
                /*If the ENTER key is pressed, prevent the form from being submitted,*/
                e.preventDefault();
                if (currentFocus > -1) {
                    /*and simulate a click on the "active" item:*/
                    if (x) x[currentFocus].click();
                }
            }
        });

        function addActive(x) {
            /*a function to classify an item as "active":*/
            if (!x) return false;
            /*start by removing the "active" class on all items:*/
            removeActive(x);
            if (currentFocus >= x.length) currentFocus = 0;
            if (currentFocus < 0) currentFocus = (x.length - 1);
            /*add class "autocomplete-active":*/
            x[currentFocus].classList.add("autocomplete-active");
        }

        function removeActive(x) {
            /*a function to remove the "active" class from all autocomplete items:*/
            for (var i = 0; i < x.length; i++) {
                x[i].classList.remove("autocomplete-active");
            }
        }

        function closeAllLists(elmnt) {
            /*close all autocomplete lists in the document,
            except the one passed as an argument:*/
            var x = document.getElementsByClassName("autocomplete-items");
            for (var i = 0; i < x.length; i++) {
                if (elmnt != x[i] && elmnt != inp) {
                    x[i].parentNode.removeChild(x[i]);
                }
            }
        }
        /*execute a function when someone clicks in the document:*/
        document.addEventListener("click", function(e) {
            closeAllLists(e.target);
        });
    }

    /*An array containing all the country names in the world:*/
    var countries = ["Accounting", "Airlines/Aviation", "Alternative Dispute Resolution", "Alternative Medicine", "Animation", "Apparel/Fashion", "Architecture/Planning", "Arts/Crafts", "Automotive", "Aviation/Aerospace", "Banking/Mortgage", "Biotechnology/Greentech", "Broadcast Media", "Building Materials", "Business Supplies/Equipment", "Capital Markets/Hedge Fund/Private Equity", "Chemicals", "Civic/Social Organization", "Civil Engineering", "Commercial Real Estate", "Computer Games", "Computer Hardware", "Computer Networking", "Computer Software/Engineering", "Computer/Network Security", "Construction", "Consumer Electronics", "Consumer Goods", "Consumer Services", "Cosmetics", "Dairy", "Defense/Space", "Design", "E-Learning", "Education Management", "Electrical/Electronic Manufacturing", "Entertainment/Movie Production", "Environmental Services", "Events Services", "Executive Office", "Facilities Services", "Farming", "Financial Services", "Fine Art", "Fishery", "Food Production", "Food/Beverages", "Fundraising", "Furniture", "Gambling/Casinos", "Glass/Ceramics/Concrete", "Government Administration", "Government Relations", "Graphic Design/Web Design", "Health/Fitness", "Higher Education/Acadamia", "Hospital/Health Care", "Hospitality", "Human Resources/HR", "Import/Export", "Individual/Family Services", "Industrial Automation", "Information Services", "Information Technology/IT", "Insurance", "International Affairs", "International Trade/Development", "Internet", "Investment Banking/Venture", "Investment Management/Hedge Fund/Private Equity", "Judiciary", "Law Enforcement", "Law Practice/Law Firms", "Legal Services", "Legislative Office", "Leisure/Travel", "Library", "Logistics/Procurement", "Luxury Goods/Jewelry", "Machinery", "Management Consulting", "Maritime", "Market Research", "Marketing/Advertising/Sales", "Mechanical or Industrial Engineering", "Media Production", "Medical Equipment", "Medical Practice", "Mental Health Care", "Military Industry", "Mining/Metals", "Motion Pictures/Film", "Museums/Institutions", "Music", "Nanotechnology", "Newspapers/Journalism", "Non-Profit/Volunteering", "Oil/Energy/Solar/Greentech", "Online Publishing", "Other Industry", "Outsourcing/Offshoring", "Package/Freight Delivery", "Packaging/Containers", "Paper/Forest Products", "Performing Arts", "Pharmaceuticals", "Philanthropy", "Photography", "Plastics", "Political Organization", "Primary/Secondary Education", "Printing", "Professional Training", "Program Development", "Public Relations/PR", "Public Safety", "Publishing Industry", "Railroad Manufacture", "Ranching", "Real Estate/Mortgage", "Recreational Facilities/Services", "Religious Institutions", "Renewables/Environment", "Research Industry", "Restaurants", "Retail Industry", "Security/Investigations", "Semiconductors", "Shipbuilding", "Sporting Goods", "Sports", "Staffing/Recruiting", "Supermarkets", "Telecommunications", "Textiles", "Think Tanks", "Tobacco", "Translation/Localization", "Transportation", "Utilities", "Venture Capital/VC", "Veterinary", "Warehousing", "Wholesale", "Wine/Spirits", "Wireless", "Writing/Editing"];
    var courses = ["Archaeology and Anthropology", "Biochemistry (Molecular and Cellular)", "Biology", "Biomedical Sciences", "Chemistry", "Classical Archaeology and Ancient History", "Classics", "Classics and English", "Classics and Modern Languages", "Classics and Oriental Studies", "Computer Science", "Computer Science and Philosophy", "Earth Sciences (Geology)", "Economics and Management", "Engineering Science", "English Language and Literature", "English and Modern Languages", "European and Middle Eastern Languages", "Fine Art", "Geography", "History", "History (Ancient and Modern)", "History and Economics", "History and English", "History and Modern Languages", "History and Politics", "History of Art", "Human Sciences", "Law (Jurisprudence)", "Materials Science", "Mathematics", "Mathematics and Computer Science", "Mathematics and Philosophy", "Mathematics and Statistics", "Medicine", "Medicine (graduate entry)", "Modern Languages", "Modern Languages and Linguistics", "Music", "Oriental Studies", "Philosophy and Modern Languages", "Philosophy, Politics and Economics (PPE)", "Philosophy and Theology", "Physics", "Physics and Philosophy", "Psychology (Experimental)", "Psychology, Philosophy and Linguistics", "Religion and Oriental Studies", "Theology and Religion"];
    /*initiate the autocomplete function on the "myInput" element, and pass along the countries array as possible autocomplete values:*/
    autocomplete(document.getElementById("myInput"), countries);
    autocomplete(document.getElementById("myInput1"), countries);
    autocomplete(document.getElementById("myInput2"), countries);
    autocomplete(document.getElementById("courses"), courses);
</script>
</div>
</body>
<br />

<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        .collapsible {
            background-color: #777;
            color: white;
            cursor: pointer;
            padding: 18px;
            width: 100%;
            border: none;
            text-align: left;
            outline: none;
            font-size: 15px;
        }

        .active,
        .collapsible:hover {
            background-color: #555;
        }

        .content {
            padding: 0 18px;
            display: none;
            overflow: hidden;
            background-color: #f1f1f1;
        }
    </style>
</head>

<style>
    .iframe {
        min-height: 250px;
        width: 100%;
        overflow: hidden;
        margin-bottom: -10px;
    }

    @media only screen and (max-width: 700px) {

        .iframe {
            min-height: 650px;
            width: 100%;
        }

    }
</style>
        <?php
            include_once "components/footer.php";
        ?>
    </body>
</html>