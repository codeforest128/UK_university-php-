<?php


include('../classes/DB.php');
include('../classes/login.php');
            
            
print_r($_SESSION);

      
          
?>