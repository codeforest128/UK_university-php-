<head>
	<title>OCH | <?php echo $title; ?></title>

	<!--/tags -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="keywords" content="Conceit Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
	<script type="application/x-javascript">
		addEventListener("load", function () {
			setTimeout(hideURLbar, 0);
		}, false);

		function hideURLbar() {
			window.scrollTo(0, 1);
		}
	</script>
	<!--//tags -->
	<?php
	    if ($title == "Account" || $title == "Add Details") {
	?>
	    <link rel="stylesheet" href="assets/fonts/fontawesome-all.min.css">
	<?php
	    }
	?>
    <link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
	<link href="css/single.css" rel="stylesheet" type="text/css" />
	<link href="css/font-awesome.css" rel="stylesheet">
	<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
	<link href="css/prettyPhoto.css" rel="stylesheet" type="text/css" />
	<!-- //for bootstrap working -->
	<link href="https://fonts.googleapis.com/css?family=Raleway:100,100i,200,300,300i,400,400i,500,500i,600,600i,700,800" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,300i,400,400i,600,600i,700" rel="stylesheet">
	<?php
	    if ($title == "Contact Us") {
	?>
	    <link href="css/contact.css" rel="stylesheet" type"text/css" />
	<?php
	    }
	    if ($title == "Our Team" || $title == "Our Societies") {
	?>
	    <link href="css/team.css" rel="stylesheet" type="text/css"/>
	<?php
	    }
	    if ($title == "Account" || $title == "Add Details") {
	?>
        <link rel="stylesheet" href="assets/fonts/ionicons.min.css">
        <link rel="stylesheet" href="assets/fonts/simple-line-icons.min.css">
        <link rel="stylesheet" href="assets/css/Bootstrap-Tags-Input.css">
	<?php
	    }
	    if ($title == "Add Details") {
	?>
	    <link rel="stylesheet" href="css/add_details.css">
	<?php
	    }
	?>
</head>