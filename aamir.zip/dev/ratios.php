<?php 
include('../../classes/DB.php');

$ethnicity = array("White English", "Asian Chinese", "White Welsh", "Asian Other", "Asian Indian", "Black British", "White Other", "Mixed White Other", "Asian Bangladeshi", "Arab", "Black African", "Asian Pakistani", "Mixed White and Black Caribbean", "Black Caribbean", "Prefer not to say");

$gender = array("Male", "Female", "Non-binary/other", "Prefer not to say");

$tote = count(DB::query("SELECT * FROM posts WHERE ethnicity != ''"));

foreach($ethnicity as $ratio){
$eth = DB::query("SELECT * FROM posts WHERE ethnicity = '$ratio'");
echo ($ratio.' = '.count($eth).' = '.round(((count($eth)/$tote)*100)).'<br>');

}

foreach($gender as $gratio){
$eth = DB::query("SELECT * FROM posts WHERE gender = '$gratio'");
echo ($gratio.' = '.count($eth).' = '.round(((count($eth)/$tote)*100)).'<br>');

}
?>
