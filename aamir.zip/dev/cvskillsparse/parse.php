<?php

$string = array("Sebastian", "Aldous", "History", "philanthropy", "economics", "Royal", "a", "towards", "b", "George", "Hampshire", "Basil" );

foreach($string as $search){
    if( strpos(file_get_contents("cv.pdf"),$search) !== false) {
        $skills .= $search;
    } else {
    echo('<br>'.$search);
    }
}
echo("<br><strong>".$skills."</strong");

include ('PdfToText.phpclass') ;
$pdf 	=  new PdfToText ( 'cv.pdf' ) ;
echo $pdf ; 		// or you could also write : echo ( string ) $pdf ;
?>