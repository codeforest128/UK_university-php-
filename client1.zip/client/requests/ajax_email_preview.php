<!DOCTYPE html>
<html>
<head>
    <title></title>
    <style>
    body {
        font-family: Montserrat,sans-serif;
    }
</style>
</head>
<body>

    <div style="">
                    <div style="height: 3em; background: #00003C; text-align: center;">
                    </div>
                    <div style="margin: 20px;"><?php echo $_POST['message']; ?>
                    </div>
                    <hr/>
                    <div style="text-align: center">
                        <p style="font-size: 0.8em"><?php echo date('Y');?> Varsity Careers Hub</p>
                    </div>
                </div>

</body>
</html>




                


