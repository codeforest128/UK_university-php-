<?php

namespace ConvertApi\Error;

class Api extends Base
{
}