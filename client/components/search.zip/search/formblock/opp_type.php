<div class="formrow"> 
    <label class="checklabel" for="career-check-<?php echo $search_type; ?>">Career</label>
    <input class="checkbox1" type="checkbox" name="career" id="career-check-<?php echo $search_type; ?>">
</div>
<div class="formrow">
    <label class="checklabel" for="intern-check-<?php echo $search_type; ?>">Internship</label>
    <input class="checkbox1" type="checkbox" name="intern" id="intern-check-<?php echo $search_type; ?>">
</div>